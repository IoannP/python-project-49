### Hexlet tests and linter status:
[![Actions Status](https://github.com/IoannP/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/IoannP/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/68632d83030a93083e0f/maintainability)](https://codeclimate.com/github/IoannP/python-project-49/maintainability)
